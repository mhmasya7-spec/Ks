package com.example.platehunter

import android.content.ContentResolver
import android.net.Uri
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.zip.ZipInputStream

/** Reads CSV and modern Excel XLSX without uploading the file. */
object SpreadsheetReader {
    /** headers: column titles; plateCol: index of the plate column; rows: data rows (all columns kept). */
    class WantedTable(val headers: List<String>, val plateCol: Int, val rows: List<List<String>>)

    fun readWanted(resolver: ContentResolver, uri: Uri): WantedTable = buildTable(readRows(resolver, uri))

    private fun readRows(resolver: ContentResolver, uri: Uri): List<List<String>> {
        val name = resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else ""
        }.orEmpty().lowercase()
        return when {
            name.endsWith(".xlsx") -> readXlsx(resolver, uri)
            name.endsWith(".csv") || name.endsWith(".txt") -> readCsv(resolver, uri)
            name.endsWith(".xls") -> throw IllegalArgumentException("صيغة XLS القديمة غير مدعومة؛ افتح الملف في Excel واحفظه بصيغة XLSX أو CSV")
            else -> try { readXlsx(resolver, uri) } catch (_: Exception) { readCsv(resolver, uri) }
        }
    }

    private fun readCsv(resolver: ContentResolver, uri: Uri): List<List<String>> {
        val rows = resolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readLines() }
            ?: throw IllegalArgumentException("تعذر فتح الملف")
        return rows.filter { it.isNotBlank() }.map { splitCsv(it) }
    }

    private fun splitCsv(line: String): List<String> {
        val out = mutableListOf<String>(); val cell = StringBuilder(); var quoted = false; var i = 0
        while (i < line.length) {
            val ch = line[i]
            if (ch == '"') {
                if (quoted && i + 1 < line.length && line[i + 1] == '"') { cell.append('"'); i++ }
                else quoted = !quoted
            } else if ((ch == ',' || ch == ';' || ch == '\t') && !quoted) { out.add(cell.toString().trim()); cell.setLength(0) }
            else cell.append(ch)
            i++
        }
        out.add(cell.toString().trim()); return out
    }

    private fun readXlsx(resolver: ContentResolver, uri: Uri): List<List<String>> {
        val zip = ZipInputStream(resolver.openInputStream(uri) ?: throw IllegalArgumentException("تعذر فتح الملف"))
        val entries = mutableMapOf<String, ByteArray>()
        zip.use { z -> var e = z.nextEntry; while (e != null) { if (!e.isDirectory && (e.name == "xl/sharedStrings.xml" || e.name.startsWith("xl/worksheets/sheet") && e.name.endsWith(".xml"))) entries[e.name] = z.readBytes(); e = z.nextEntry } }
        val shared = entries["xl/sharedStrings.xml"]?.let(::parseSharedStrings).orEmpty()
        val sheet = entries["xl/worksheets/sheet1.xml"] ?: entries.entries.firstOrNull { it.key.startsWith("xl/worksheets/sheet") }?.value
            ?: throw IllegalArgumentException("لم أجد ورقة بيانات داخل ملف XLSX")
        val rows = mutableListOf<List<String>>()
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(sheet.inputStream(), "UTF-8")
        var inRow = false; var inCell = false; var inValue = false; var cellType = ""; var cellRef = ""; var value = ""
        var row = mutableMapOf<Int, String>()
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            when (parser.eventType) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> { inRow = true; row = mutableMapOf() }
                    "c" -> { inCell = true; cellType = parser.getAttributeValue(null, "t") ?: ""; cellRef = parser.getAttributeValue(null, "r") ?: ""; value = "" }
                    "v", "t" -> if (inCell) inValue = true
                }
                XmlPullParser.TEXT -> if (inValue) value += parser.text
                XmlPullParser.END_TAG -> when (parser.name) {
                    "v", "t" -> inValue = false
                    "c" -> { val col = columnIndex(cellRef); row[col] = if (cellType == "s") shared.getOrNull(value.toIntOrNull() ?: -1).orEmpty() else value; inCell = false }
                    "row" -> { if (inRow) rows.add((0..(row.keys.maxOrNull() ?: -1)).map { row[it].orEmpty() }); inRow = false }
                }
            }
            parser.next()
        }
        return rows
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val out = mutableListOf<String>(); val p = XmlPullParserFactory.newInstance().newPullParser(); p.setInput(bytes.inputStream(), "UTF-8")
        var inItem = false; var inText = false; val sb = StringBuilder()
        while (p.eventType != XmlPullParser.END_DOCUMENT) {
            when (p.eventType) {
                XmlPullParser.START_TAG -> when (p.name) { "si" -> { inItem = true; sb.setLength(0) }; "t" -> if (inItem) inText = true }
                XmlPullParser.TEXT -> if (inText) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) { "t" -> inText = false; "si" -> { out.add(sb.toString()); inItem = false } }
            }; p.next()
        }
        return out
    }
    private fun columnIndex(ref: String): Int { var n = 0; for (c in ref.takeWhile { it.isLetter() }.uppercase()) n = n * 26 + (c - 'A' + 1); return n - 1 }
    private fun buildTable(rows: List<List<String>>): WantedTable {
        if (rows.isEmpty()) return WantedTable(emptyList(), 0, emptyList())
        val isPlateHeader = { t: String -> t.contains("لوحة") || t.contains("لوحه") || t.contains("plate", true) }
        val hi = rows.indexOfFirst { r -> r.any(isPlateHeader) }
        return if (hi >= 0) {
            val h = rows[hi].mapIndexed { i, t -> t.trim().ifBlank { "عمود ${i + 1}" } }
            WantedTable(h, rows[hi].indexOfFirst(isPlateHeader), rows.drop(hi + 1))
        } else {
            val n = rows.maxOf { it.size }
            WantedTable((1..n).map { "عمود $it" }, 0, rows)
        }
    }
}
